import app from "./geometry/geometry.config.js";
import { getCursor } from "./geometry/cursor/cursor.js";
import { clear } from "./utils.js";
import { createPoint } from "./geometry/point/point.js";

const pointBtn = document.getElementById("point");
pointBtn.addEventListener("click", createPoint);

const cursor = getCursor();
const shapes = app.getShapes();

function update(dt) {
  cursor.update(dt);
  for (const shape of shapes) {
    shape.update(dt);
  }
}

function draw() {
  cursor.draw();
  for (const shape of shapes) {
    shape.draw();
  }
}

let oldTimeStamp = 0;
function appLoop(timestamp) {
  let dt = (timestamp - oldTimeStamp) / 1000;
  oldTimeStamp = timestamp;

  clear(app.getCanvas("shape"));

  update(dt);

  draw();
  
  requestAnimationFrame(appLoop);
}
requestAnimationFrame(appLoop);
