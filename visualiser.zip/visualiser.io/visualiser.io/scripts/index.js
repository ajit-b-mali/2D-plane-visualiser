import { redirectTo } from "./utils.js";

redirectTo("geometry");
