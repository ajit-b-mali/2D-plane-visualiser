import { initializeApp } from "./initializeApp.js";

const board = document.getElementById("board");
const cursor = document.getElementById("cursor");
const shape = document.getElementById("shape");
const mainScreenEl = document.getElementById("screen");

const app = initializeApp({ board, cursor, shape }, mainScreenEl);

export default app;