import { circlePath } from "../../utils.js";
import { boardToScreen, screenToBoard } from "../createScreen.js";
import { getCursor } from "../cursor/cursor.js";
import app from "../geometry.config.js";

function Point(x, y) {
  const canvas = document.getElementById("shape");
  const ctx = canvas.getContext("2d");
  let posX = x;
  let posY = y;
  let isDeleted = false;
  let id = Math.random().toString();

  function get(prop) {
    switch (prop) {
      case "pos": return {x: posX, y: posY};
      case "id": return id;
      case "isDeleted": return isDeleted;

      default: return null;
    }
  }

  function update(dt) {
    
  }

  function draw() {
    let [x, y] = boardToScreen(posX, posY);
    ctx.strokeStyle = "white"
    circlePath(ctx, x, y, 5);
    ctx.stroke();

    ctx.fillStyle = "white";
    circlePath(ctx, x, y, 3);
    ctx.fill();
  }

  return Object.freeze({
    get,
    draw,
    update
  });
}

function createPoint() {
  const screenEl = app.getMainScreen();
  const shapes = app.getShapes();

  function foo() {
    const cursor = getCursor();
    const cursorX = cursor.get("x");
    const cursorY = cursor.get("y");
    const [x, y] = screenToBoard(event.offsetX, event.offsetY)
    shapes.push(Point(x, y));
    screenEl.removeEventListener("click", foo);
    for (const shape of shapes) {
      console.log(shape.get("pos"));
    }
  }
  screenEl.addEventListener("click", foo);
}

export { createPoint };