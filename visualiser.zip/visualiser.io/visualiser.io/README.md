# 2D-plane-visualiser

## from HUB's Company

This is our 3rd year major project where we made a web app for geometry visualisation and chart/graph visualisation.

In Geometry, We addes user friendly navigation just like photoshop/godot/ ,etc to move the canvas. User can draw any shapes, they can perform specific operation like transform, rotate, add perpendicular, parallel line, etc

In Graph, User can add data specific to the selected graph type, And user will get the graph created aitomatically. It is also user friendly and we have tried to program defensive.


started - 14122023

## link 
https://ajit-b-mali.github.io/2D-plane-visualiser/index.html
